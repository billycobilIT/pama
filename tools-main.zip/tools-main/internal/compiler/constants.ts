export const SCOPE_PRIVATE_PREFIX = "___R$";
