import * as n from "@internal/ast";

export type AnyHTMLChildNode =
	| n.HTMLDoctypeTag
	| n.HTMLElement
	| n.HTMLText
	| n.HTMLCdataTag;
