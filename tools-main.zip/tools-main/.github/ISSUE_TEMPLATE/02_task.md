---
name: '📎 Task'
about: Specific actionable task. Typically opened by existing contributors. If you aren't sure then use the "Miscellaneous" template.
title: '📎 <TITLE>'
labels: 'task'
---
