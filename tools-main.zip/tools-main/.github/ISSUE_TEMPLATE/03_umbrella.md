---
name: '☂️ Umbrella'
about: Discuss and track high level goals for a collection of other issues. Should only be opened with prior discussion.
title: '☂️ <TITLE>'
labels: 'umbrella'
---
